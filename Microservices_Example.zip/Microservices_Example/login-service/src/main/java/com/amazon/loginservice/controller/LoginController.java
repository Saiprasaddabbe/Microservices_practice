package com.amazon.loginservice.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/login")
@Slf4j
public class LoginController {

    @Autowired
    CartService cartService;
    @GetMapping
    public String login(){
        return "login success";
    }

    @GetMapping("/get-my-products")
    public String getProducts(){
        log.info("LoginController - inside getProducts method");
        return cartService.getProducts();
    }

}
